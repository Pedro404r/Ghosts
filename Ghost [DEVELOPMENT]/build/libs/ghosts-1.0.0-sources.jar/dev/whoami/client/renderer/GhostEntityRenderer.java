package dev.whoami.client.renderer;

import dev.whoami.GhostsClient;
import dev.whoami.client.model.GhostEntityModel;
import dev.whoami.entity.GhostEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class GhostEntityRenderer extends class_927<GhostEntity, GhostEntityModel> {

    public GhostEntityRenderer(class_5617.class_5618 context) {
        super(context, new GhostEntityModel(context.method_32167(GhostsClient.MODEL_CUBE_LAYER)), 0.5f);
    }

    @Override
    public class_2960 getTexture(GhostEntity entity) {
        return class_2960.method_60655("ghosts", "textures/entity/ghost/ghost.png");
    }
}
