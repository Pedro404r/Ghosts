package dev.whoami.client.model;

import dev.whoami.entity.GhostEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class GhostEntityModel extends class_5597<GhostEntity>{
    // declarar todas as partes do modelo
    private final class_630 root;
    private final class_630 Asas;
    private final class_630 Capa;
    private final class_630 Torso;
    private final class_630 Cabeca;
    private final class_630 OssoExposto;
    private final class_630 OssosPerna;
    private final class_630 Pe;

    public GhostEntityModel(class_630 root) {
        this.root = root;
        this.Asas = root.method_32086("Asas");
        this.Capa = root.method_32086("Capa");
        this.Torso = root.method_32086("Torso");
        this.Cabeca = root.method_32086("Cabeca");
        this.OssoExposto = root.method_32086("OssoExposto");
        this.OssosPerna = root.method_32086("OssosPerna");
        this.Pe = root.method_32086("Pe");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();

        // ASAS
        class_5610 Asas = modelPartData.method_32117("Asas",
                class_5606.method_32108().method_32101(16, 15).method_32098(-7.0F, -3.8F, -1.0F, 5.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32090(3.0F, 14.6F, 0.0F));

        class_5610 cube_r1 = Asas.method_32117("cube_r1",
                class_5606.method_32108().method_32101(0, 21).method_32098(-3.6728F, 0.5403F, -1.0F, 5.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(3.9F, -1.2F, -1.1F, 3.1052F, -0.0377F, -2.373F));

        class_5610 cube_r2 = Asas.method_32117("cube_r2",
                class_5606.method_32108().method_32101(16, 9).method_32098(-4.7F, -2.6F, -1.0F, 6.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(3.9F, -1.2F, -1.1F, -3.1416F, -0.0524F, 3.1416F));

        class_5610 cube_r3 = Asas.method_32117("cube_r3",
                class_5606.method_32108().method_32101(16, 12).method_32098(-4.1828F, -1.1099F, -1.0F, 6.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(3.9F, -1.2F, -1.1F, 3.1211F, -0.0482F, -2.7397F));

        class_5610 cube_r4 = Asas.method_32117("cube_r4",
                class_5606.method_32108().method_32101(12, 18).method_32098(-4.0F, -2.0F, -1.0F, 5.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(-1.3F, 0.4F, 0.0F, 0.0F, 0.0F, -0.7679F));

        class_5610 cube_r5 = Asas.method_32117("cube_r5",
                class_5606.method_32108().method_32101(0, 18).method_32098(-4.0F, -2.0F, -1.0F, 5.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(-2.2F, -0.7F, 0.0F, 0.0F, 0.0F, -0.4014F));

        // CAPA
        class_5610 Capa = modelPartData.method_32117("Capa",
                class_5606.method_32108(),
                class_5603.method_32090(0.0F, 24.0F, 0.0F));

        class_5610 cube_r6 = Capa.method_32117("cube_r6",
                class_5606.method_32108().method_32101(0, 0).method_32098(-3.0F, -2.0F, -2.0F, 6.0F, 10.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(3.3F, -11.7F, 2.3F, 0.6458F, 0.0F, 0.0F));

        // TORSO
        class_5610 Torso = modelPartData.method_32117("Torso",
                class_5606.method_32108().method_32101(14, 0).method_32098(1.4F, -12.0F, -2.1F, 4.0F, 7.0F, 2.0F, new class_5605(0.0F)),
                class_5603.method_32090(0.0F, 24.0F, 0.0F));

        // CABEÇA
        class_5610 Cabeca = modelPartData.method_32117("Cabeca",
                class_5606.method_32108().method_32101(0, 11).method_32098(-3.8F, -3.2F, -2.9F, 5.0F, 4.0F, 3.0F, new class_5605(0.0F)),
                class_5603.method_32090(4.7F, 10.0F, 0.0F));

        // OSSO EXPOSTO
        class_5610 OssoExposto = modelPartData.method_32117("OssoExposto",
                class_5606.method_32108()
                        .method_32101(24, 18).method_32098(2.0F, -13.9F, -1.7F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F))
                        .method_32101(26, 6).method_32098(3.6F, -13.9F, -1.7F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32090(0.0F, 24.0F, 0.0F));

        // OSSOS DA PERNA
        class_5610 OssosPerna = modelPartData.method_32117("OssosPerna",
                class_5606.method_32108()
                        .method_32101(20, 24).method_32098(2.1F, -5.0F, -1.6F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F))
                        .method_32101(24, 24).method_32098(3.6F, -5.0F, -1.6F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32090(0.0F, 24.0F, 0.0F));

        class_5610 cube_r7 = OssosPerna.method_32117("cube_r7",
                class_5606.method_32108()
                        .method_32101(26, 3).method_32098(-1.0F, -2.0F, 0.0F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F))
                        .method_32101(26, 0).method_32098(0.5F, -2.0F, 0.0F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)),
                class_5603.method_32091(3.1F, -1.7F, -0.9F, 0.384F, 0.0F, 0.0F));

        // PÉ
        class_5610 Pe = modelPartData.method_32117("Pe",
                class_5606.method_32108()
                        .method_32101(8, 24).method_32098(-1.1F, -0.8F, -0.8F, 1.0F, 1.0F, 2.0F, new class_5605(0.0F))
                        .method_32101(14, 24).method_32098(0.4F, -0.8F, -0.8F, 1.0F, 1.0F, 2.0F, new class_5605(0.0F)),
                class_5603.method_32090(3.2F, 22.6F, -1.2F));

        return class_5607.method_32110(modelData, 32, 32);
    }

    @Override
    public void setAngles(GhostEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.method_32008().method_32088().forEach(class_630::method_41923);

        // Rotação da cabeça baseada no olhar
        this.Cabeca.field_3675 = headYaw * 0.017453292F;
        this.Cabeca.field_3654 = headPitch * 0.017453292F;

    }

    @Override
    public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
        // Renderiza apenas a raiz - ela renderizará todos os filhos automaticamente
        this.root.method_22699(matrices, vertices, light, overlay, color);
    }

    @Override
    public class_630 method_32008() {
        return root;
    }
}