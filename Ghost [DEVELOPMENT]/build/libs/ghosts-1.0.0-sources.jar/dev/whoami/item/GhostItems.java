package dev.whoami.item;

import dev.whoami.Ghosts;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class GhostItems {

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062)
                .register((itemGroup) -> {
                    itemGroup.method_45421(GhostItems.DEMON_TOTEM);
                    itemGroup.method_45421(GhostItems.GLOCK_17);
                });
    }
    public static class_1792 register(class_1792 item, String id){
        class_2960 itemID = class_2960.method_60655(Ghosts.MOD_ID, id);

        class_1792 registeredItem = class_2378.method_10230(class_7923.field_41178, itemID, item);

        return registeredItem;
    }

    public static final class_1792 DEMON_TOTEM = register(
            new class_1792(new class_1792.class_1793()),
            "demon_totem"
    );

    public static final class_1792 GLOCK_17 = register(
            new GlockItem(new class_1792.class_1793().method_7889(1)),
            "glock_17"
    );
}
