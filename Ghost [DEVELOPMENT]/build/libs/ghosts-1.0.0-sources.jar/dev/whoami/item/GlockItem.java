package dev.whoami.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class GlockItem extends class_1792 {
    public GlockItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);

        // Som de disparo (Pistol-like)
        world.method_60511(null, user.method_23317(), user.method_23318(), user.method_23321(),
                class_3417.field_15152, class_3419.field_15248, 0.8F, 2.0F);

        if (!world.field_9236) {
            // Cooldown de 0.25 segundos (5 ticks) para ser rápida
            user.method_7357().method_7906(this, 5);

            // Aqui você pode adicionar lógica de dano ou projétil depois
        }

        return class_1271.method_22427(itemStack);
    }
}