package dev.whoami.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1331;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_8111;
import net.minecraft.entity.ai.goal.*;
import java.util.EnumSet;
import java.util.List;

public class GhostEntity extends class_1314 {

    public GhostEntity(class_1299<? extends class_1314> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 20, true);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new EatMembraneGoal(this));
        this.field_6201.method_6277(2, new class_1366(this, 1.2D, false));
        this.field_6201.method_6277(3, new class_1394(this, 1.0D));
        this.field_6201.method_6277(4, new class_1361(this, class_1657.class, 8.0F));

        this.field_6185.method_6277(1, new class_1399(this));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 birdNavigation = new class_1407(this, world);
        birdNavigation.method_6332(true);
        birdNavigation.method_6354(true);
        birdNavigation.method_6331(true);
        return birdNavigation;
    }

    @Override
    public void method_5773() {
        this.field_5960 = true;
        super.method_5773();
        this.field_5960 = false;
        this.method_5875(true);

        if (!this.method_37908().field_9236) {
            class_2338 pos = this.method_24515();
            if (this.method_37908().method_8320(pos).method_26234(this.method_37908(), pos)) {
                this.method_5762(0, 0.08, 0);
            } else if (!this.method_37908().method_8320(pos.method_10074()).method_26215()) {
                if (this.method_18798().field_1351 < 0) {
                    this.method_18799(this.method_18798().method_18805(1, 0, 1));
                }
            }
        }
    }

    @Override
    public boolean method_5679(class_1282 damageSource) {
        return damageSource.method_49708(class_8111.field_42340) || super.method_5679(damageSource);
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false;
    }

    public static class_5132.class_5133 createGhostAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0)
                .method_26868(class_5134.field_23719, 0.25)
                .method_26868(class_5134.field_23720, 0.6)
                .method_26868(class_5134.field_23721, 4.0)
                .method_26868(class_5134.field_23717, 64.0);
    }

    static class EatMembraneGoal extends class_1352 {
        private final GhostEntity ghost;
        private class_1542 targetItem;

        public EatMembraneGoal(GhostEntity ghost) {
            this.ghost = ghost;
            this.method_6265(EnumSet.of(class_1352.class_4134.field_18405));
        }

        @Override
        public boolean method_6264() {
            if (this.ghost.method_6032() >= this.ghost.method_6063()) return false;
            List<class_1542> items = this.ghost.method_37908().method_8390(class_1542.class,
                    this.ghost.method_5829().method_1014(16.0D),
                    item -> item.method_6983().method_31574(class_1802.field_8614));
            if (!items.isEmpty()) {
                this.targetItem = items.get(0);
                return true;
            }
            return false;
        }

        @Override
        public void method_6268() {
            if (this.targetItem != null && this.targetItem.method_5805()) {
                this.ghost.method_5942().method_6335(this.targetItem, 1.2D);
                if (this.ghost.method_5829().method_1014(1.0D).method_994(this.targetItem.method_5829())) {
                    this.ghost.method_6025(5.0F);
                    this.targetItem.method_6983().method_7934(1);
                    this.method_6270();
                }
            }
        }

        @Override
        public boolean method_6266() {
            return this.targetItem != null && this.targetItem.method_5805() && this.ghost.method_6032() < this.ghost.method_6063();
        }
    }
}