package dev.whoami;

import dev.whoami.client.model.GhostEntityModel;
import dev.whoami.client.renderer.GhostEntityRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

@Environment(EnvType.CLIENT)
public class GhostsClient implements ClientModInitializer {
    public static final class_5601 MODEL_CUBE_LAYER = new class_5601(class_2960.method_60655("ghosts", "ghost"), "main");
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(Ghosts.GHOST, (context) -> {
            return new GhostEntityRenderer(context);
        });

        EntityModelLayerRegistry.registerModelLayer(MODEL_CUBE_LAYER, GhostEntityModel::getTexturedModelData);
    }
}
