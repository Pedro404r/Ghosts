package dev.whoami;

import dev.whoami.entity.GhostEntity;
import dev.whoami.item.GhostItems;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Ghosts implements ModInitializer {

    public static final String MOD_ID = "ghosts";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1299<GhostEntity> GHOST = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(MOD_ID, "ghost"),
            class_1299.class_1300.method_5903(GhostEntity::new, class_1311.field_6294)
                    .method_17687(0.75f, 0.75f)
                    .method_5905("ghost")
    );

    public static final class_1792 GHOST_SPAWN_EGG = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(MOD_ID, "ghost_spawn_egg"),
            new class_1826(GHOST, 0x123456, 0x789abc, new class_1792.class_1793())
    );

    @Override
    public void onInitialize() {
        GhostItems.initialize();
        LOGGER.info("Inicializando > [GhostItems]");
        FabricDefaultAttributeRegistry.register(GHOST, GhostEntity.createGhostAttributes());
        
        LOGGER.info("GhostEntity e Spawn Egg inicializados!");

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(content -> {
            content.method_45421(GHOST_SPAWN_EGG);
        });
    }
}
